# Using Spark Course
The repo contains the notebooks used in the **Using Spark** course given at Supercomputing Centre of Galicia.
