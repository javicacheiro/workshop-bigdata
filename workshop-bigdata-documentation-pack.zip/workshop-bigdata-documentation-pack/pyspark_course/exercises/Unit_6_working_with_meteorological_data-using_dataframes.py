from __future__ import print_function


if __name__ == '__main__':
    ???
