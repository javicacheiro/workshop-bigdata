df.withColumn: to add new columns to the dataframe

    tdata = tdata.withColumn("Age",  when((tdata.Age == "") & (tdata.Survived == "0") , "NewValue").otherwise(tdata.Age))

How to set multiple conditions using operators: & | ~

To negate a condition use: ~

    t1.filter(~t1.body.like('%vps4.cesga.es%')).take(4)


Add example of how to use rlike we have to escape the regular expression expressions with 4 \:

    body not rlike 'SW\\\\d\\\\d-\\\\d'

In scala using datasets allows to use a function as argument for the filter function
